import React from 'react';
import Hero from '../components/Hero';
import AboutSection from '../components/AboutSection';
import SkillsSection from '../components/SkillsSection';
import ServicesSection from '../components/ServicesSection';
import WorkSection from '../components/WorkSection';
import ContactSection from '../components/ContactSection';
import { motion } from 'framer-motion';

const Home: React.FC = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Hero />
      <AboutSection />
      <SkillsSection />
      <ServicesSection />
      <WorkSection />
      <ContactSection />
    </motion.div>
  );
};

export default Home;
