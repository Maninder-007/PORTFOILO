import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { PROJECTS, CASE_STUDIES_DATA } from '../constants';
import { motion, useScroll, useSpring } from 'framer-motion';
import { ArrowLeft, ArrowRight, Tag, Calendar, PenTool, CheckCircle, Layout, TrendingUp, Users, Shield, User } from 'lucide-react';

const CaseStudy: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const projectBasic = PROJECTS.find(p => p.id === id);
  const projectDetails = id ? CASE_STUDIES_DATA[id] : undefined;
  
  const [activeSection, setActiveSection] = useState('overview');

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  useEffect(() => {
    const handleScroll = () => {
      const sections = ['overview', 'problem', 'roles', 'process', 'design', 'results'];
      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          if (rect.top >= 0 && rect.top <= 300) {
            setActiveSection(section);
            break;
          }
        }
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  if (!projectBasic || !projectDetails) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background text-white">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Project Data Not Found</h2>
          <Link to="/" className="text-primary hover:underline">Return Home</Link>
        </div>
      </div>
    );
  }

  const currentIndex = PROJECTS.findIndex(p => p.id === id);
  const nextProject = PROJECTS[(currentIndex + 1) % PROJECTS.length];

  const getRoleIcon = (title: string) => {
    if (title.toLowerCase().includes('admin')) return <Shield className="text-primary" size={24} />;
    if (title.toLowerCase().includes('worker')) return <User className="text-primary" size={24} />;
    if (title.toLowerCase().includes('guard')) return <Shield className="text-primary" size={24} />;
    return <Users className="text-primary" size={24} />;
  }

  return (
    <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="bg-background min-h-screen pb-32"
    >
      <motion.div className="fixed top-0 left-0 right-0 h-1 bg-primary origin-left z-50" style={{ scaleX }} />

      <nav className="fixed top-24 left-6 z-40 hidden xl:block">
         <Link to="/#work" className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/5 transition-all">
            <ArrowLeft size={20} />
         </Link>
      </nav>

      <header className="relative pt-32 pb-20 px-6 bg-gradient-to-b from-surface to-background border-b border-white/5">
        <div className="max-w-7xl auto mx-auto">
          <div className="mb-8">
             <Link to="/#work" className="xl:hidden inline-flex items-center text-sm text-gray-400 hover:text-primary mb-6 transition-colors">
               <ArrowLeft size={16} className="mr-2" /> Back to Projects
             </Link>
             <div className="flex flex-wrap gap-4 mb-6">
                {projectBasic.tags.map(tag => (
                  <span key={tag} className="px-3 py-1 text-xs font-bold uppercase tracking-wider text-primary bg-primary/10 rounded-full border border-primary/20">
                    {tag}
                  </span>
                ))}
             </div>
             <h1 className="text-5xl md:text-7xl font-display font-bold text-white mb-6 leading-[1.1]">
               {projectBasic.title}
             </h1>
             <p className="text-xl md:text-2xl text-gray-400 max-w-3xl font-light leading-relaxed">
               {projectBasic.description}
             </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 pt-8 border-t border-white/10 mt-12">
             <div>
                <h3 className="text-xs text-gray-500 uppercase tracking-widest font-bold mb-2 flex items-center gap-2"><Layout size={14}/> Role</h3>
                <p className="text-white font-medium">{projectBasic.role}</p>
             </div>
             <div>
                <h3 className="text-xs text-gray-500 uppercase tracking-widest font-bold mb-2 flex items-center gap-2"><Calendar size={14}/> Timeline</h3>
                <p className="text-white font-medium">{projectDetails.timeline}</p>
             </div>
             <div>
                <h3 className="text-xs text-gray-500 uppercase tracking-widest font-bold mb-2 flex items-center gap-2"><PenTool size={14}/> Tools</h3>
                <p className="text-white font-medium">{projectDetails.tools.join(', ')}</p>
             </div>
             <div>
                <h3 className="text-xs text-gray-500 uppercase tracking-widest font-bold mb-2 flex items-center gap-2"><Tag size={14}/> Client</h3>
                <p className="text-white font-medium">{projectDetails.client}</p>
             </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 mt-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
           
           <div className="hidden lg:block lg:col-span-3">
              <div className="sticky top-40 space-y-1">
                 {['Overview', 'Problem', 'Roles', 'Process', 'Design', 'Results'].map(item => {
                    const id = item.toLowerCase();
                    const isActive = activeSection === id;
                    return (
                       <a 
                         key={id}
                         href={`#${id}`}
                         onClick={(e) => {
                           e.preventDefault();
                           document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
                           setActiveSection(id);
                         }}
                         className={`block py-3 px-4 border-l-2 transition-all duration-300 text-sm font-medium ${isActive ? 'border-primary text-white bg-white/5' : 'border-white/10 text-gray-500 hover:text-gray-300'}`}
                       >
                         {item}
                       </a>
                    )
                 })}
              </div>
           </div>

           <div className="lg:col-span-9 space-y-32">
              
              <section id="overview" className="space-y-8 scroll-mt-32">
                 <div className="rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
                    <img src={projectBasic.imageUrl} alt="Hero" className="w-full h-auto" />
                 </div>
                 <div className="prose prose-invert max-w-none">
                    <h3 className="text-2xl font-bold text-white mb-4">Project Overview</h3>
                    <p className="text-gray-400 text-lg leading-relaxed">{projectBasic.longDescription}</p>
                 </div>
              </section>

              <section id="problem" className="scroll-mt-32">
                 <div className="bg-surface border border-white/5 p-10 md:p-14 rounded-3xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-[80px] -translate-y-1/2 translate-x-1/2"></div>
                    <h2 className="text-sm font-bold text-primary uppercase tracking-widest mb-6">Problem Statement</h2>
                    <p className="text-3xl md:text-4xl font-display font-bold text-white leading-tight mb-10">
                      "{projectDetails.problemStatement}"
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                      <div className="space-y-6">
                        <h3 className="text-lg font-bold text-white flex items-center gap-2"><CheckCircle size={20} className="text-primary"/> Project Goals</h3>
                        <ul className="space-y-4">
                          {projectDetails.goals.map((goal, idx) => (
                             <li key={idx} className="flex gap-4 text-gray-400">
                                <span className="text-primary font-bold">•</span>
                                {goal}
                             </li>
                          ))}
                        </ul>
                      </div>
                      {projectDetails.targetUsers && (
                        <div className="space-y-6">
                          <h3 className="text-lg font-bold text-white flex items-center gap-2"><Users size={20} className="text-primary"/> Target Users</h3>
                          <ul className="space-y-4">
                            {projectDetails.targetUsers.map((user, idx) => (
                               <li key={idx} className="flex gap-4 text-gray-400">
                                  <span className="text-primary font-bold">•</span>
                                  {user}
                               </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                 </div>
              </section>

              {projectDetails.userRoles && (
                <section id="roles" className="scroll-mt-32">
                  <h2 className="text-3xl font-display font-bold text-white mb-12">User Roles & App Views</h2>
                  <div className="space-y-8">
                    {projectDetails.userRoles.map((role, idx) => (
                      <div key={idx} className="flex flex-col md:flex-row gap-8 p-8 border border-white/10 rounded-2xl bg-surface/50 group hover:border-primary/30 transition-all">
                        <div className="w-16 h-16 rounded-full bg-background flex items-center justify-center border border-white/10 group-hover:bg-primary group-hover:text-background transition-colors shrink-0">
                          {getRoleIcon(role.title)}
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-white mb-3">{role.title}</h3>
                          <p className="text-gray-400 leading-relaxed">{role.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>
              )}

              <section id="process" className="scroll-mt-32">
                 <h2 className="text-3xl font-display font-bold text-white mb-12">The Process</h2>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {projectDetails.process.map((step, idx) => (
                       <div key={idx} className="relative p-6 border border-white/10 rounded-2xl bg-surface/50 hover:bg-surface transition-colors">
                          <span className="text-5xl font-display font-bold text-white/5 absolute top-4 right-4">0{idx + 1}</span>
                          <h3 className="text-xl font-bold text-white mb-3 relative z-10">{step.title}</h3>
                          <p className="text-gray-400 text-sm leading-relaxed relative z-10">{step.description}</p>
                       </div>
                    ))}
                 </div>
              </section>

              <section id="design" className="scroll-mt-32 space-y-16">
                 <div>
                    <h2 className="text-3xl font-display font-bold text-white mb-8">UX Design & Wireframes</h2>
                    <p className="text-gray-400 text-lg max-w-2xl mb-12">
                       A task-based approach was used to ensure clarity across roles. We focused on intentional user flows and structural mapping to ensure a robust foundation.
                    </p>
                    
                    <div className="grid grid-cols-1 gap-12">
                       <div className="space-y-4">
                          <span className="text-sm text-gray-500 uppercase tracking-widest font-bold">Low-Fidelity Wireframes</span>
                          <div className="rounded-2xl overflow-hidden border border-white/10 bg-white/[0.02] backdrop-blur-sm p-4 md:p-12">
                             <img src={projectDetails.wireframeImage} alt="Wireframes" className="w-full h-auto rounded-lg shadow-2xl" />
                          </div>
                       </div>
                       
                       <div className="space-y-4">
                          <span className="text-sm text-gray-500 uppercase tracking-widest font-bold">Final Visual Design (Final UI)</span>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                             {projectDetails.uiImages.map((img, idx) => (
                                <div key={idx} className="rounded-xl overflow-hidden border border-white/10 shadow-lg group">
                                   <img src={img} alt={`UI Screen ${idx+1}`} className="w-full h-auto group-hover:scale-105 transition-transform duration-500" />
                                </div>
                             ))}
                          </div>
                       </div>
                    </div>
                 </div>
                 
                 <div className="bg-surface/30 p-8 rounded-2xl border border-white/5">
                    <h3 className="text-xl font-bold text-white mb-4">Outcome & Learnings</h3>
                    <p className="text-gray-400 leading-relaxed mb-6">{projectDetails.solution}</p>
                    <p className="text-gray-300 italic font-medium">"{projectDetails.learnings}"</p>
                 </div>
              </section>

              <section id="results" className="scroll-mt-32 mb-20">
                 <h2 className="text-3xl font-display font-bold text-white mb-12">Impact & Results</h2>
                 
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
                    {projectDetails.results.map((result, idx) => (
                       <div key={idx} className="bg-gradient-to-br from-surface to-background p-8 rounded-2xl border border-white/10 text-center hover:border-primary/30 transition-colors">
                          <TrendingUp className="w-8 h-8 text-primary mx-auto mb-4 opacity-80" />
                          <div className="text-4xl font-bold text-white mb-2">{result.metric}</div>
                          <div className="text-sm text-gray-500 uppercase tracking-widest">{result.label}</div>
                       </div>
                    ))}
                 </div>
              </section>

              <div className="border-t border-white/10 pt-12">
                 <Link to={`/project/${nextProject.id}`} className="group block">
                    <span className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Next Case Study</span>
                    <div className="flex items-center justify-between">
                       <h3 className="text-3xl md:text-5xl font-display font-bold text-white group-hover:text-primary transition-colors">
                          {nextProject.title}
                       </h3>
                       <ArrowRight className="text-white group-hover:text-primary group-hover:translate-x-2 transition-all" size={32} />
                    </div>
                 </Link>
              </div>

           </div>
        </div>
      </div>
    </motion.div>
  );
};

export default CaseStudy;