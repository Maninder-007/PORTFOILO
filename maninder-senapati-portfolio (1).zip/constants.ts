import { Project, Service, SkillCategory, ProcessStep, CaseStudyDetails } from './types';

export const PROJECTS: Project[] = [
  {
    id: 'trivani',
    title: 'Trivani',
    role: 'UI/UX Designer',
    tags: ['Mobile App', 'Warehouse', 'Workforce Management'],
    description: 'An authenticated workforce management system using selfie verification and location tracking for warehouse operations.',
    imageUrl: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&q=80&w=1200', 
    longDescription: 'Trivani is a mobile application built to manage warehouse workforce attendance and on-ground security operations through a single, reliable system. The app enables workers to punch in and punch out using selfie verification and live location access, while security guards document heavy vehicle movement and store meter readings with photographic proof.'
  },
  {
    id: 'saas',
    title: 'LinkedIn Growth OS',
    role: 'Product Designer',
    tags: ['SaaS', 'AI', 'LinkedIn Marketing'],
    description: 'An all-in-one AI-powered SaaS platform for LinkedIn content creation, automation, and lead generation.',
    imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=1200',
    longDescription: 'A comprehensive LinkedIn Growth Operating System designed to replace fragmented tools with a single, intelligent, and secure platform. This project focuses on turning LinkedIn into a predictable engine for content, growth, and qualified leads using assistive AI.'
  },
  {
    id: 'br-career-tech',
    title: 'Intelligent Resume System',
    role: 'UX Designer',
    tags: ['SaaS', 'AI', 'Professional Identity'],
    description: 'An advanced AI-driven resume engine that adapts professional identities based on intent, geography, and industry.',
    imageUrl: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?auto=format&fit=crop&q=80&w=1200',
    longDescription: 'BR Career Tech aims to build an advanced resume system that goes far beyond traditional templates. The vision was to design a unified SaaS platform that works as a professional identity engine, capable of adapting resumes based on intent, audience, geography, industry, and career stage.'
  }
];

export const CASE_STUDIES_DATA: Record<string, CaseStudyDetails> = {
  'trivani': {
    id: 'trivani',
    client: 'Trivani Logistics',
    timeline: '6-8 Weeks',
    tools: ['Figma', 'FigJam'],
    problemStatement: 'Most warehouse operations still depend on manual attendance registers and disconnected security logs. This results in inaccurate timings, proxy attendance, lack of visual proof, and poor operational visibility for administrators.',
    goals: [
      'Prevent proxy attendance using selfie and location verification',
      'Simplify attendance process for warehouse workers',
      'Provide administrators with real-time operational data',
      'Enable security guards to capture vehicle and meter info with minimal effort'
    ],
    targetUsers: [
      'Warehouse Workers',
      'Security Guards',
      'Warehouse Administrators'
    ],
    userRoles: [
      {
        title: 'Admin Side',
        description: 'Central control panel for monitoring attendance, verifying selfie logs, reviewing vehicle entries, and managing leave requests with data clarity and structured dashboards.'
      },
      {
        title: 'Worker Side',
        description: 'Simple, camera-first flow for authenticated punch-in/out using live location and selfie verification to prevent proxy attendance.'
      },
      {
        title: 'Security Guard Side',
        description: 'Camera-driven interface for logging heavy vehicle movements and capturing meter readings with photographic proof, designed for quick use in operational environments.'
      }
    ],
    challenge: 'Translating complex manual warehouse workflows into a simple, tamper-proof digital system that works for users with varying levels of tech literacy.',
    process: [
      { title: 'Stakeholder Research', description: 'Discussions and on-ground observation of warehouse attendance and security processes.' },
      { title: 'Information Architecture', description: 'Designing task-based navigation tailored to role-specific requirements (Admin, Worker, Guard).' },
      { title: 'UX Flows & Wireframes', description: 'Creating low-fidelity wireframes focused on camera placement and thumb-friendly interactions.' },
      { title: 'Visual Design', description: 'Developing a clean, professional UI with high readability and functional hierarchy for industrial environments.' }
    ],
    solution: 'A role-based mobile system combining location-based verification, selfie authentication, and camera-first documentation to ensure operational transparency and trust.',
    wireframeImage: 'https://images.unsplash.com/photo-1620336655055-088d06e76fb0?auto=format&fit=crop&q=80&w=1200',
    uiImages: [
      'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800'
    ],
    results: [
      { metric: '100%', label: 'Authenticity Rate' },
      { metric: 'Real-time', label: 'Admin Visibility' },
      { metric: 'Zero', label: 'Proxy Attendance' }
    ],
    learnings: 'Simplicity is paramount in operational apps. Visual proof is the ultimate foundation for trust in distributed workforce management.'
  },
  'saas': {
    id: 'saas',
    client: 'GrowthLabs SaaS',
    timeline: '3 Months',
    tools: ['Figma', 'Miro', 'OpenAI API'],
    problemStatement: 'LinkedIn is a powerful growth channel, but users struggle with inconsistent posting, lack of ideas, time-consuming workflows, and a lack of clear systems to convert engagement into real leads.',
    goals: [
      'Reduce time to publish to under 10 minutes per week',
      'Unify the full LinkedIn workflow in one dashboard',
      'Make AI feel assistive, not complex',
      'Enable organic lead generation by default',
      'Ensure safe automation (anti-ban UX)'
    ],
    targetUsers: [
      'Content Creators & Solopreneurs',
      'Founders & Business Owners',
      'Marketing Teams'
    ],
    userRoles: [
      {
        title: 'Primary User (Creator/Founder)',
        description: 'Focuses on the Weekly AI Content Planner. Uses the AI Content Studio to generate hooks, stories, and carousels, and the Lead Gen system to track engaged prospects.'
      },
      {
        title: 'Marketing Manager',
        description: 'Focuses on Trend Monitoring and Analytics. Manages team calendars and tracks the Account Growth Score across multiple client accounts.'
      }
    ],
    challenge: 'How might we help professionals consistently create high-quality LinkedIn content and convert engagement into leads—without complexity, risk of bans, or tool overload?',
    process: [
      { title: 'User Research', description: 'Identified key pain points: "I get likes, but no leads" and "I don\'t know what to post consistently".' },
      { title: 'Workflow Mapping', description: 'Structured the platform around a linear journey: Ideas → Creation → Planning → Publishing → Engagement → Leads → Analytics.' },
      { title: 'AI-First UX Design', description: 'Designed an assistive interface where AI generates content but humans always maintain final review and control.' },
      { title: 'Dashboard Prototyping', description: 'Developed a unified dashboard that answers three critical questions: What to do today? What is performing? Who to talk to?' }
    ],
    solution: 'A "LinkedIn Growth Operating System" that unifies the entire creation and lead-gen workflow. Features include a Weekly AI Content Planner, an AI Content Studio for visuals/copy, and a Smart Lead Tracking system.',
    wireframeImage: 'https://images.unsplash.com/photo-1581291518633-83b4ebd1d83e?auto=format&fit=crop&q=80&w=1200',
    uiImages: [
      'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&q=80&w=800'
    ],
    results: [
      { metric: '80%', label: 'Time Saved' },
      { metric: '100%', label: 'Post Consistency' },
      { metric: 'Premium', label: 'UX Rating' }
    ],
    learnings: 'Clarity over complexity is essential for SaaS tools. Progressive disclosure allows for powerful AI features without overwhelming the user on their first visit.'
  },
  'br-career-tech': {
    id: 'br-career-tech',
    client: 'BR Career Tech',
    timeline: '10-12 Weeks',
    tools: ['Figma', 'FigJam', 'OpenAI'],
    problemStatement: 'Most resume builders rely heavily on generic templates and fail to understand why a resume is being created. Users struggle with irrelevant fields, ATS rejections, and receive no real guidance on how to improve their professional profiles.',
    goals: [
      'Remove friction through context-aware progressive disclosure',
      'Integrate real-time ATS intelligence into the editor',
      'Develop an adaptive framework for multiple intent-based identities',
      'Provide actionable, AI-driven feedback loops'
    ],
    targetUsers: [
      'Freshers & Experienced Professionals',
      'International Job Seekers & Freelancers',
      'Academic Researchers & Senior Executives'
    ],
    userRoles: [
      {
        title: 'Manual Resume Creator',
        description: 'Guided flow for users starting from scratch. Captures intent (Job, Visa, Academic) and unlocks relevant sections (Publications for academics, Portfolio for freelancers).'
      },
      {
        title: 'AI-Optimized Optimizer',
        description: 'Flow for existing resume holders. AI parses current data, identifies skill gaps, and suggests role-aligned improvements in a three-panel workspace.'
      }
    ],
    challenge: 'Designing a resume system that dynamically adapts its structure, language, and layout based on user intent while remaining simple and non-intimidating.',
    process: [
      { title: 'UX Strategy', description: 'Defining the adaptive framework where content reshaping happens based on career level, domain, and geography.' },
      { title: 'Information Architecture', description: 'Creating a shallow, focused architecture moving from profile classification to template selection and builder workspace.' },
      { title: 'Integrated ATS Engine', description: 'Designing a real-time feedback loop that evaluates keyword match, formatting safety, and section completeness while typing.' },
      { title: 'Three-Panel Workspace', description: 'Prototyping a focused editor with sections on the left, live preview in the center, and ATS feedback on the right.' }
    ],
    solution: 'The product transforms resume creation into an AI-driven, context-aware experience that produces role-aligned, ATS-compliant, and globally usable resumes strategically aligned with user goals.',
    wireframeImage: 'https://images.unsplash.com/photo-1586717791821-3f44a563eb4c?auto=format&fit=crop&q=80&w=1200',
    uiImages: [
      'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?auto=format&fit=crop&q=80&w=800'
    ],
    results: [
      { metric: '92%', label: 'Completion Rate' },
      { metric: 'ATS-100', label: 'Global Compliance' },
      { metric: '10m', label: 'Avg Time to First Export' }
    ],
    learnings: 'Context is prioritised over completeness. Intelligence should replace static templates, and transparency is maintained in all AI-driven interactions to preserve user trust.'
  }
};

export const SERVICES: Service[] = [
  { id: 'ui-design', title: 'UI Design', description: 'Crafting pixel-perfect interfaces.', iconName: 'Layout' },
  { id: 'ux-design', title: 'UX Design', description: 'Building intuitive user flows.', iconName: 'Smartphone' },
  { id: 'research', title: 'User Research', description: 'Conducting usability testing.', iconName: 'Search' },
  { id: 'interaction', title: 'Interaction Design', description: 'Micro-interactions and animations.', iconName: 'MousePointer' },
  { id: 'responsive', title: 'Responsive Design', description: 'Cross-device compatibility.', iconName: 'Monitor' },
  { id: 'journey', title: 'Journey Mapping', description: 'Visualizing user experiences.', iconName: 'Map' },
  { id: 'systems', title: 'Design Systems', description: 'Scalable design languages.', iconName: 'Layers' }
];

export const SKILLS: SkillCategory[] = [
  { title: 'Design', skills: ['UI/UX Principles', 'Wireframing', 'Prototyping', 'Design Thinking', 'Responsive Design', 'Journey Mapping'] },
  { title: 'Research', skills: ['User Research', 'Usability Testing', 'Survey Design', 'Ethnographic Research', 'Competitive Analysis'] },
  { title: 'Tools', skills: ['Figma', 'Adobe XD', 'Sketch', 'Framer', 'Miro', 'Microsoft Forms'] }
];

export const PROCESS_STEPS: ProcessStep[] = [
  { id: 'research', title: 'Research', description: 'Understanding the user.', iconName: 'Search' },
  { id: 'define', title: 'Define', description: 'Pinpointing the challenge.', iconName: 'Target' },
  { id: 'ideate', title: 'Ideate', description: 'Brainstorming concepts.', iconName: 'Lightbulb' },
  { id: 'design', title: 'Design', description: 'Crafting the interface.', iconName: 'PenTool' },
  { id: 'build', title: 'Build', description: 'Implementation collaboration.', iconName: 'Code' }
];
