
export interface Project {
  id: string;
  title: string;
  role: string;
  tags: string[];
  description: string;
  imageUrl: string;
  longDescription?: string;
}

export interface Service {
  id: string;
  title: string;
  description: string;
  iconName: 'Layout' | 'Smartphone' | 'Search' | 'MousePointer' | 'Monitor' | 'Map' | 'Layers';
}

export interface SkillCategory {
  title: string;
  skills: string[];
}

export interface ProcessStep {
  id: string;
  title: string;
  description: string;
  iconName: 'Search' | 'Target' | 'Lightbulb' | 'PenTool' | 'Code';
}

export interface CaseStudyDetails {
  id: string;
  client: string;
  timeline: string;
  tools: string[];
  problemStatement: string;
  goals: string[];
  targetUsers?: string[]; // New
  userRoles?: { title: string, description: string }[]; // New
  process: {
    title: string;
    description: string;
  }[];
  challenge: string;
  solution: string;
  wireframeImage: string;
  uiImages: string[];
  results: {
    metric: string;
    label: string;
  }[];
  learnings: string;
}
