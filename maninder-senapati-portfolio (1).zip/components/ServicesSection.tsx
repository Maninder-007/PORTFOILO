
import React from 'react';
import { SERVICES } from '../constants';
import { Layout, Smartphone, Search, MousePointer, Monitor, Map, Layers } from 'lucide-react';
import { motion } from 'framer-motion';

const icons = {
  Layout,
  Smartphone,
  Search,
  MousePointer,
  Monitor,
  Map,
  Layers
};

const ServicesSection: React.FC = () => {
  const scrollToContact = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="services" className="py-32 bg-surface relative overflow-hidden">
      {/* Decorative gradient */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-primary/5 rounded-full blur-[120px] translate-x-1/2 -translate-y-1/2"></div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-8">
            <div>
                <h2 className="text-4xl md:text-5xl font-display font-bold text-white mb-6 leading-tight">
                  I am <span className="text-primary">skilled in</span>
                </h2>
                <p className="text-gray-400 max-w-xl text-lg font-light leading-relaxed">
                   I help companies build better digital products by bridging the gap between user needs and business goals.
                </p>
            </div>
            <div className="hidden md:block">
                 <a 
                   href="#contact" 
                   onClick={scrollToContact}
                   className="text-white border-b border-primary pb-1 hover:text-primary transition-colors text-sm font-bold uppercase tracking-widest cursor-pointer"
                 >
                   Start a Project
                 </a>
            </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {SERVICES.map((service, idx) => {
                const Icon = icons[service.iconName];
                return (
                    <motion.div 
                        key={service.id} 
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.1 }}
                        viewport={{ once: true }}
                        className="group relative bg-background/50 backdrop-blur-sm p-8 rounded-2xl border border-white/5 overflow-hidden hover:border-primary/30 transition-all duration-300"
                    >
                        {/* Hover Gradient Background */}
                        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                        <div className="relative z-10">
                            <div className="w-14 h-14 bg-surface rounded-xl flex items-center justify-center text-white mb-8 border border-white/5 group-hover:bg-primary group-hover:text-background group-hover:scale-110 transition-all duration-300 shadow-lg">
                                <Icon size={26} strokeWidth={1.5} />
                            </div>
                            <h3 className="text-xl font-bold text-white mb-4">{service.title}</h3>
                            <p className="text-gray-400 text-sm leading-relaxed group-hover:text-gray-300 transition-colors">
                                {service.description}
                            </p>
                        </div>
                    </motion.div>
                );
            })}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
