
import React, { useEffect, useState } from 'react';
import { useLocation, Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X } from 'lucide-react';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const isHome = location.pathname === '/';
  
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement | HTMLButtonElement>, id: string) => {
    setIsMobileMenuOpen(false);
    if (isHome) {
      e.preventDefault();
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      navigate(`/#${id}`);
    }
  };

  const navLinks = [
    { name: 'About', id: 'about' },
    { name: 'Skills', id: 'skills' },
    { name: 'Services', id: 'services' },
    { name: 'Portfolio', id: 'work' },
    { name: 'Contact', id: 'contact' },
  ];

  const whatsappLink = "https://wa.me/917077063161";

  return (
    <div className="min-h-screen flex flex-col font-sans text-secondary bg-background relative selection:bg-primary selection:text-background overflow-hidden">
      
      {/* Global Mouse Spotlight */}
      <div 
        className="pointer-events-none fixed inset-0 z-30 transition-opacity duration-300"
        style={{
          background: `radial-gradient(600px at ${mousePosition.x}px ${mousePosition.y}px, rgba(102, 252, 241, 0.08), transparent 80%)`
        }}
      />

      <header className="fixed top-0 left-0 right-0 z-50 bg-background/70 backdrop-blur-xl border-b border-white/5 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <Link to="/" className="text-xl font-display font-bold tracking-tight text-white group">
            Maninder<span className="text-primary group-hover:text-white transition-colors">.</span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-gray-400">
            {isHome ? (
              <>
                {navLinks.slice(0, 4).map((link) => (
                  <a 
                    key={link.id} 
                    href={`#${link.id}`} 
                    onClick={(e) => scrollToSection(e, link.id)} 
                    className="hover:text-primary transition-colors cursor-pointer"
                  >
                    {link.name}
                  </a>
                ))}
              </>
            ) : (
              <Link to="/" className="hover:text-primary transition-colors">Back to Home</Link>
            )}
            <a 
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="px-5 py-2.5 bg-primary/10 border border-primary/50 text-primary rounded-full text-xs font-bold uppercase tracking-wider hover:bg-primary hover:text-background transition-all shadow-[0_0_15px_rgba(102,252,241,0.1)] hover:shadow-[0_0_25px_rgba(102,252,241,0.5)] cursor-pointer"
            >
              Let's Connect
            </a>
          </nav>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden p-2 text-gray-400 hover:text-primary transition-colors"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle Menu"
          >
            {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-[60] bg-background flex flex-col items-center justify-center p-6 md:hidden"
          >
            <button 
              className="absolute top-6 right-6 p-2 text-gray-400 hover:text-primary transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <X size={32} />
            </button>
            
            <nav className="flex flex-col items-center gap-8">
              {navLinks.map((link) => (
                <a
                  key={link.id}
                  href={`#${link.id}`}
                  onClick={(e) => scrollToSection(e, link.id)}
                  className="text-3xl font-display font-bold text-white hover:text-primary transition-colors tracking-tight"
                >
                  {link.name}
                </a>
              ))}
              <div className="pt-8 border-t border-white/10 w-full flex justify-center gap-6">
                <a href="https://www.linkedin.com/in/maninder-senapati/" className="text-gray-500 hover:text-primary">LinkedIn</a>
                <a href="mailto:Manindersenapati07@gmail.com" className="text-gray-500 hover:text-primary">Email</a>
              </div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>

      <main className="flex-grow pt-20 relative z-10">
        {children}
      </main>

      <footer className="py-12 border-t border-white/5 bg-background relative z-10">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center text-sm text-gray-500 gap-4">
          <div className="font-medium text-white">Maninder Senapati</div>
          <div>© {new Date().getFullYear()} All Rights Reserved.</div>
          <div className="flex gap-4">
            <a href="https://www.linkedin.com/in/maninder-senapati/" className="hover:text-primary transition-colors">LinkedIn</a>
            <a href="mailto:Manindersenapati07@gmail.com" className="hover:text-primary transition-colors">Email</a>
          </div>
        </div>
      </footer>

      {/* Mobile Sticky CTA - Perfectly Center Aligned */}
      <motion.div 
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        transition={{ delay: 1 }}
        className="md:hidden fixed bottom-8 left-0 right-0 z-40 px-6 flex justify-center pointer-events-none"
      >
        <a 
          href={whatsappLink}
          target="_blank"
          rel="noopener noreferrer"
          className="pointer-events-auto bg-primary text-background px-10 py-4 rounded-full shadow-[0_10px_30px_rgba(102,252,241,0.3)] text-sm font-bold uppercase tracking-widest hover:scale-105 transition-transform whitespace-nowrap cursor-pointer text-center min-w-[200px]"
        >
          Let's Connect
        </a>
      </motion.div>
    </div>
  );
};

export default Layout;
