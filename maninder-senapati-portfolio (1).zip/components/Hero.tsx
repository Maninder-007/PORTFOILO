
import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Linkedin, Mail, Github, Dribbble } from 'lucide-react';

const Hero: React.FC = () => {
  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const whatsappLink = "https://wa.me/917077063161";

  return (
    <section className="min-h-[92vh] flex items-center justify-center relative overflow-hidden bg-background">
      
      {/* Background Decor */}
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 brightness-100 contrast-150 mix-blend-overlay"></div>
      
      {/* Dynamic Background Gradients */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-primary/10 rounded-full blur-[120px] opacity-50 animate-pulse-slow pointer-events-none"></div>
      <div className="absolute bottom-0 right-0 w-[600px] h-[600px] bg-purple-900/10 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="max-w-6xl mx-auto px-6 w-full relative z-10 text-center">
        
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="flex flex-col items-center"
        >
          {/* Top Label */}
          <motion.div 
             initial={{ opacity: 0, y: 20 }}
             animate={{ opacity: 1, y: 0 }}
             transition={{ delay: 0.2 }}
             className="mb-8 inline-flex items-center gap-3 px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-md"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
            </span>
            <span className="text-xs font-medium text-gray-300 tracking-widest uppercase">Available for new projects</span>
          </motion.div>
          
          {/* Main Headline */}
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-display font-bold tracking-tight text-white mb-8 leading-[1.1]">
            Designing <span className="text-gray-500 font-serif italic font-light">Intelligent</span> <br className="hidden md:block" />
            <span className="text-gradient">Digital Experiences</span>
          </h1>
          
          {/* Subheading */}
          <p className="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto leading-relaxed mb-10 font-light">
            Hi, I’m <span className="text-white font-medium">Maninder Senapati</span>. I bridge the gap between user needs and business goals, crafting pixel-perfect interfaces that are scalable, accessible, and impactful.
          </p>

          {/* CTAs */}
          <div className="flex flex-col md:flex-row items-center justify-center gap-4 w-full md:w-auto">
            <a 
              href="#work"
              onClick={(e) => scrollToSection(e, 'work')}
              className="group relative px-8 py-4 bg-primary text-background rounded-full text-sm font-bold uppercase tracking-widest overflow-hidden transition-all hover:scale-105 w-full md:w-auto cursor-pointer"
            >
              <span className="relative z-10 flex items-center justify-center gap-2">
                View My Work <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </span>
              <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-20 transition-opacity"></div>
            </a>
            
            <a 
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="px-8 py-4 border border-white/10 bg-white/5 backdrop-blur-sm text-white rounded-full text-sm font-bold uppercase tracking-widest hover:bg-white/10 hover:border-primary/50 hover:text-primary transition-all w-full md:w-auto cursor-pointer"
            >
              Let's Connect
            </a>
          </div>

          {/* Social Proof / Links */}
          <div className="mt-16 pt-8 border-t border-white/5 flex flex-col items-center gap-4">
            <span className="text-xs text-gray-600 uppercase tracking-widest">Connect with me</span>
            <div className="flex gap-8 items-center justify-center">
              <a href="https://www.linkedin.com/in/maninder-senapati/" target="_blank" rel="noreferrer" className="text-gray-500 hover:text-primary hover:scale-110 transition-all duration-300">
                <Linkedin size={22} />
              </a>
              <a href="mailto:Manindersenapati07@gmail.com" className="text-gray-500 hover:text-primary hover:scale-110 transition-all duration-300">
                <Mail size={22} />
              </a>
              <a href="#" className="text-gray-500 hover:text-primary hover:scale-110 transition-all duration-300">
                <Dribbble size={22} />
              </a>
              <a href="#" className="text-gray-500 hover:text-primary hover:scale-110 transition-all duration-300">
                <Github size={22} />
              </a>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3 text-gray-500/50 text-[10px] tracking-[0.3em] uppercase"
      >
        <span>Scroll</span>
        <div className="w-[1px] h-12 bg-gradient-to-b from-primary/50 to-transparent"></div>
      </motion.div>
    </section>
  );
};

export default Hero;
