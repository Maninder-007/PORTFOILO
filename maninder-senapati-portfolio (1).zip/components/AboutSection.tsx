import React from 'react';
import { motion } from 'framer-motion';

const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-surface relative">
      <div className="max-w-4xl mx-auto px-6">
        <div className="space-y-12">
            <div className="text-center">
              <h2 className="text-4xl md:text-5xl font-display font-bold text-white mb-6">
                About <span className="text-primary">Me</span>
              </h2>
              <div className="w-20 h-1 bg-primary mx-auto rounded-full opacity-50"></div>
            </div>

            <div className="space-y-6 text-xl text-gray-400 leading-relaxed text-center font-light">
              <p>
                I am <span className="text-white font-medium">Maninder Senapati</span>, a user-focused UX Designer with two years of experience crafting intuitive and engaging digital experiences. 
              </p>
              <p>
                Demonstrated expertise in conducting user research, designing wireframes and prototypes, and collaborating with cross-functional teams to deliver impactful solutions.
              </p>
              <p>
                Eager to apply foundational skills and a passion for design to make a meaningful contribution to a dynamic, user-centered organization.
              </p>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-2 gap-6 pt-8 max-w-lg mx-auto">
                <div className="p-6 bg-background rounded-2xl border border-gray-800 flex flex-col items-center justify-center hover:border-primary/30 transition-colors">
                    <span className="block text-4xl font-display font-bold text-white mb-2">02+</span>
                    <span className="text-sm text-gray-500 uppercase tracking-widest text-center">Years Experience</span>
                </div>
                <div className="p-6 bg-background rounded-2xl border border-gray-800 flex flex-col items-center justify-center hover:border-primary/30 transition-colors">
                    <span className="block text-4xl font-display font-bold text-white mb-2">10+</span>
                    <span className="text-sm text-gray-500 uppercase tracking-widest text-center">Projects Completed</span>
                </div>
            </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
