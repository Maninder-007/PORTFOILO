
import React from 'react';
import { Mail, Linkedin, MapPin, Phone } from 'lucide-react';

const ContactSection: React.FC = () => {
  const whatsappLink = "https://wa.me/917077063161";

  return (
    <section id="contact" className="py-24 bg-surface relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            
            <div className="space-y-8">
                <h2 className="text-4xl font-display font-bold text-white">
                  Let’s <span className="text-primary">Connect</span>
                </h2>
                <p className="text-gray-400 text-lg">
                  Have a project in mind or just want to say hi? I'm always open to discussing new opportunities.
                </p>

                <div className="space-y-6 pt-4">
                    <div className="flex items-center gap-4 text-gray-300">
                        <div className="w-12 h-12 bg-background rounded-full flex items-center justify-center text-primary border border-gray-800">
                            <Mail size={20} />
                        </div>
                        <div>
                            <span className="block text-xs text-gray-500 uppercase tracking-wider">Email</span>
                            <a href="mailto:Manindersenapati07@gmail.com" className="hover:text-primary transition-colors">Manindersenapati07@gmail.com</a>
                        </div>
                    </div>
                    <div className="flex items-center gap-4 text-gray-300">
                        <div className="w-12 h-12 bg-background rounded-full flex items-center justify-center text-primary border border-gray-800">
                            <Phone size={20} />
                        </div>
                        <div>
                            <span className="block text-xs text-gray-500 uppercase tracking-wider">Phone / WhatsApp</span>
                            <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">+91 7077063161</a>
                        </div>
                    </div>
                    <div className="flex items-center gap-4 text-gray-300">
                        <div className="w-12 h-12 bg-background rounded-full flex items-center justify-center text-primary border border-gray-800">
                            <Linkedin size={20} />
                        </div>
                        <div>
                            <span className="block text-xs text-gray-500 uppercase tracking-wider">LinkedIn</span>
                            <a href="https://www.linkedin.com/in/maninder-senapati/" target="_blank" rel="noreferrer" className="hover:text-primary transition-colors">maninder-senapati</a>
                        </div>
                    </div>
                    <div className="flex items-center gap-4 text-gray-300">
                        <div className="w-12 h-12 bg-background rounded-full flex items-center justify-center text-primary border border-gray-800">
                            <MapPin size={20} />
                        </div>
                        <div>
                            <span className="block text-xs text-gray-500 uppercase tracking-wider">Location</span>
                            <span>Bhubaneswar, India</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Contact Form */}
            <div className="bg-background p-8 rounded-2xl border border-gray-800 shadow-xl">
                <form className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <label className="text-sm font-medium text-gray-400">Name</label>
                            <input type="text" className="w-full bg-surface border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-primary transition-colors" placeholder="John Doe" />
                        </div>
                        <div className="space-y-2">
                            <label className="text-sm font-medium text-gray-400">Email</label>
                            <input type="email" className="w-full bg-surface border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-primary transition-colors" placeholder="john@example.com" />
                        </div>
                    </div>
                    <div className="space-y-2">
                        <label className="text-sm font-medium text-gray-400">Subject</label>
                        <input type="text" className="w-full bg-surface border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-primary transition-colors" placeholder="Project Inquiry" />
                    </div>
                    <div className="space-y-2">
                        <label className="text-sm font-medium text-gray-400">Message</label>
                        <textarea rows={4} className="w-full bg-surface border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-primary transition-colors" placeholder="Tell me about your project..."></textarea>
                    </div>
                    <button type="button" className="w-full bg-primary text-background font-bold py-4 rounded-lg hover:bg-white transition-colors uppercase tracking-widest text-sm">
                        Send Message
                    </button>
                </form>
            </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
