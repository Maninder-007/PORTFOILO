import React from 'react';
import ProjectCard from './ProjectCard';
import { PROJECTS } from '../constants';

const WorkSection: React.FC = () => {
  return (
    <section id="work" className="py-24 bg-background">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-16 flex flex-col md:flex-row justify-between items-end gap-6">
            <div>
                <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">
                  Selected <span className="text-primary">Projects</span>
                </h2>
                <p className="text-gray-400 max-w-lg">
                    Notable projects showcasing my expertise in product design and user experience.
                </p>
            </div>
            {/* Optional decorative line */}
            <div className="hidden md:block h-[1px] bg-gray-800 flex-grow ml-12 mb-4"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {PROJECTS.map((project, index) => (
            <ProjectCard key={project.id} project={project} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default WorkSection;
