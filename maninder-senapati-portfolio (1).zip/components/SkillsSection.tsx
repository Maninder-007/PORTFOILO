import React from 'react';
import { SKILLS } from '../constants';
import { motion } from 'framer-motion';

const SkillsSection: React.FC = () => {
  return (
    <section id="skills" className="py-24 bg-background">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
           <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">My <span className="text-primary">Skills</span></h2>
           <p className="text-gray-400 max-w-2xl mx-auto text-lg">
             I am skilled in <span className="text-white font-medium">Design</span>, <span className="text-white font-medium">Research</span>, and <span className="text-white font-medium">Tools</span> to build comprehensive digital products.
           </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {SKILLS.map((category, idx) => (
            <motion.div 
              key={category.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              viewport={{ once: true }}
              className="bg-surface p-8 rounded-2xl border border-gray-800 hover:border-primary/50 transition-colors duration-300 flex flex-col h-full"
            >
              <h3 className="text-xl font-bold text-white mb-6 border-b border-gray-700 pb-4 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-primary shadow-[0_0_10px_rgba(102,252,241,0.5)]"></span>
                {category.title}
              </h3>
              <div className="flex flex-wrap gap-3">
                {category.skills.map((skill) => (
                  <span 
                    key={skill} 
                    className="px-4 py-2 bg-background text-gray-300 rounded-md text-sm font-medium border border-gray-800 hover:text-primary hover:border-primary transition-all cursor-default"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
