import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Target, Lightbulb, PenTool, Code, ChevronDown } from 'lucide-react';
import { PROCESS_STEPS } from '../constants';

const icons = {
  Search,
  Target,
  Lightbulb,
  PenTool,
  Code
};

const ProcessSection: React.FC = () => {
  const [activeStep, setActiveStep] = useState<string | null>(null);

  const toggleStep = (id: string) => {
    setActiveStep(activeStep === id ? null : id);
  };

  return (
    <section id="process" className="py-24 bg-white border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-3xl font-semibold text-gray-900 mb-16">Design Process</h2>
        
        {/* Desktop Horizontal Flow (mapped to grid for better control) */}
        <div className="hidden lg:grid grid-cols-5 gap-4">
          {PROCESS_STEPS.map((step, index) => {
            const Icon = icons[step.iconName];
            return (
              <div 
                key={step.id} 
                className="relative group cursor-pointer"
                onClick={() => toggleStep(step.id)}
              >
                <div className="flex flex-col items-center text-center space-y-4 p-6 rounded-xl hover:bg-gray-50 transition-colors duration-300">
                   <div className={`p-4 rounded-full bg-gray-100 text-gray-600 transition-colors duration-300 ${activeStep === step.id ? 'bg-gray-900 text-white' : ''}`}>
                      <Icon size={24} />
                   </div>
                   <div className="space-y-2">
                     <h3 className="font-medium text-gray-900">{step.title}</h3>
                     <AnimatePresence>
                       {activeStep === step.id && (
                         <motion.p 
                           initial={{ opacity: 0, height: 0 }}
                           animate={{ opacity: 1, height: 'auto' }}
                           exit={{ opacity: 0, height: 0 }}
                           className="text-sm text-gray-500 leading-relaxed"
                         >
                           {step.description}
                         </motion.p>
                       )}
                     </AnimatePresence>
                   </div>
                   {/* Connector Line */}
                   {index < PROCESS_STEPS.length - 1 && (
                      <div className="absolute top-10 -right-[10%] w-[20%] h-[2px] bg-gray-100 hidden lg:block -z-10" />
                   )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Mobile Vertical Accordion */}
        <div className="lg:hidden space-y-4">
          {PROCESS_STEPS.map((step) => {
             const Icon = icons[step.iconName];
             const isActive = activeStep === step.id;
             return (
               <div 
                  key={step.id} 
                  onClick={() => toggleStep(step.id)}
                  className={`p-4 rounded-xl border transition-all duration-300 ${isActive ? 'border-gray-900 bg-gray-50' : 'border-gray-200 bg-white'}`}
               >
                 <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`p-2 rounded-lg ${isActive ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-600'}`}>
                        <Icon size={20} />
                      </div>
                      <h3 className="font-medium text-gray-900">{step.title}</h3>
                    </div>
                    <ChevronDown size={16} className={`transition-transform duration-300 ${isActive ? 'rotate-180' : ''}`} />
                 </div>
                 <AnimatePresence>
                   {isActive && (
                     <motion.div 
                       initial={{ opacity: 0, height: 0 }}
                       animate={{ opacity: 1, height: 'auto' }}
                       exit={{ opacity: 0, height: 0 }}
                       className="overflow-hidden"
                     >
                       <p className="pt-4 text-sm text-gray-600 leading-relaxed pl-[52px]">
                         {step.description}
                       </p>
                     </motion.div>
                   )}
                 </AnimatePresence>
               </div>
             )
          })}
        </div>
      </div>
    </section>
  );
};

export default ProcessSection;
